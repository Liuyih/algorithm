to run the program, just:
python3 wrestler.py sample.txt

a example would be python3 wrestler.py wrestler1.txt